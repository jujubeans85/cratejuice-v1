Juju Drops — v3 (Embed + Notes + Archive)
-----------------------------------------------
Includes:
• /cbo/index.html — embedded SoundCloud player + lane note
• /mmi/index.html — embedded SoundCloud player + lane note
• /cbo/archive.html & /mmi/archive.html — on-device archive (localStorage)
• /_redirects updated

Deploy:
• Replace /cbo and /mmi folders in your Netlify site, plus /_redirects.

Archive behavior:
• Each time a lane page loads, it saves the current drop (URL + time) into localStorage (50 max).
• Archive is per-device (privacy-safe) and exportable as JSON.

SoundCloud URL used (both lanes):
https://on.soundcloud.com/y7gl9iWKCiKRwYl5rx

Generated: 2025-09-10T14:53:38
