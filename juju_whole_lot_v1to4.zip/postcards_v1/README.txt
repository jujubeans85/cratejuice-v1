
SONIC POSTCARDS v1 — Print Pack
================================
• Size: A6 landscape (148 x 105 mm) at 300 dpi → 1748 x 1240 px JPGs
• Fronts: /fronts/front_{cbo|mmi}_NN_A6_300dpi.jpg
• Backs: /backs/back_{cbo|mmi}_A6_300dpi.jpg
• QR targets:
  - https://heartfelt-malasada-f52e30.netlify.app/cbo/
  - https://heartfelt-malasada-f52e30.netlify.app/mmi/
• Web preview: open /web/index.html

Printing tips:
• For postcards, print fronts and backs duplex; otherwise print fronts and glue to blank A6 card.
• Leave at least 3 mm bleed if your printer allows; edges already rounded visually.
• If you want the QR color-inverted or embedded into artwork spots, tell me which images and I’ll mask it in.

— Generated: 2025-09-10T14:27:38
