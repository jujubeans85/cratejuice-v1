DROP PATCH — SoundCloud
Sets both lanes (cbo/mmi) to open:
https://on.soundcloud.com/y7gl9iWKCiKRwYl5rx

Deploy: replace /cbo/index.html and /mmi/index.html in your Netlify site.
Generated: 2025-09-10T14:41:15