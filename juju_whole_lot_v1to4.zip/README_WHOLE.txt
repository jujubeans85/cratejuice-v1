JUJU — THE WHOLE LOT (v1+v2+v3+v4)
===================================
This bundle contains all deliverables so far:

1. postcards_v1/
   • Sonic Postcards print pack (fronts & backs for C’bo and M’mi, QR codes embedded)

2. patch_soundcloud_v2/
   • Netlify patch for C’bo & M’mi lanes to open SoundCloud link directly

3. embed_archive_v3/
   • Embedded SoundCloud player in /cbo and /mmi
   • Lane-specific notes
   • Local archive pages (/cbo/archive.html, /mmi/archive.html)

4. index_patch_v4/
   • Root index.html redirect
   • _redirects rules to fix base domain 404

Usage:
• For web deploy: use embed_archive_v3 + index_patch_v4.
• For printing: use postcards_v1.
• Keep patch_soundcloud_v2 for reference/rollbacks.

Generated: 2025-09-10T15:33:34
