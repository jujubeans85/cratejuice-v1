Netlify Patch — Root Index + Redirects
----------------------------------------
Adds:
• /index.html → auto-redirects to /cbo/
• _redirects → root (/) → /cbo/index.html

Deploy:
• Drop both files at the root of your Netlify site.
• This will eliminate 404s when hitting the base domain.

Generated: 2025-09-10T15:10:00
